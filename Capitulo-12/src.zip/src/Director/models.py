from django.db import models
from Peliculas import models as pmd

# Create your models here.
class Director(models.Model):
    Nombre = models.CharField(max_length=25)
    Apellido = models.CharField(max_length=35)
    Nacionalidad = models.CharField(max_length=2)
    Fecha_Nacimiento = models.DateField()
    Vigencia = models.BooleanField()
    peliculas = models.ManyToManyField(pmd.Pelicula)
    def __str__(self):
        return self.Nombre
