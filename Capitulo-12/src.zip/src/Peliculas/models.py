from django.db import models

# Create your models here.
class Genero(models.Model):
    genero = models.CharField(max_length=27)
    
    def __str__(self):
        return self.genero

class Pelicula(models.Model):
    titulo = models.CharField(max_length=27, blank=True)
    sumario = models.TextField(max_length=500, blank=True)
    fecha = models.DateField()
    genero = models.ManyToManyField(Genero)

    def __str__(self):
        return self.titulo